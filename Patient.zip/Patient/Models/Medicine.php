<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Medicine extends Model
{
 protected $table = 'medicines';

    protected $fillable = [
        'name',
        'category',
        'dosage_form',
        'strength',
        'indication',
        'ingredient_id',
    ];

    // ─── علاقة مع المادة الفعالة ──────────────────────────────────────
    public function activeIngredient()
    {
        return $this->belongsTo(ActiveIngredient::class, 'ingredient_id', 'id');
    }
    }
