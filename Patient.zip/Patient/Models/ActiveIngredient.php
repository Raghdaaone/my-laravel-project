<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ActiveIngredient extends Model
{
   protected $table = 'active_ingredient';

    protected $fillable = [
        'name',
        'classification',
    ];

    // ─── علاقة مع الأدوية ─────────────────────────────────────────────
    public function medicines()
    {
        return $this->hasMany(Medicine::class, 'ingredient_id', 'id');
    }}
