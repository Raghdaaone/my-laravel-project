<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class PatientMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // تحقق أن المستخدم مسجل دخوله
        if (! $request->user()) {
            return response()->json([
                'message' => 'يجب تسجيل الدخول أولاً',
            ], 401);
        }

        // تحقق أن المستخدم مريض
        if ($request->user()->role !== 'patient') {
            return response()->json([
                'message' => 'ليس لديك صلاحية الوصول',
            ], 403);
        }

        // تحقق أن الحساب مفعّل
        if (! $request->user()->is_active) {
            return response()->json([
                'message' => 'الحساب غير مفعّل. تحقق من بريدك الإلكتروني',
            ], 403);
        }

        return $next($request);
    }
}
