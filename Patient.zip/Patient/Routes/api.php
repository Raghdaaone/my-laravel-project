<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Patient\ProfileController;
use App\Http\Controllers\Patient\MedicineSearchController;
use App\Http\Controllers\Patient\AuthController;
use App\Http\Controllers\Patient\GoogleAuthController;

Route::middleware(['auth:sanctum'])->group(function () {
    Route::get('patient/profile',       [ProfileController::class, 'show']);
    Route::put('patient/profile',       [ProfileController::class, 'update']);
    Route::post('patient/change-password', [ProfileController::class, 'changePassword']);

    // Medicine Search
    Route::get('medicines/search', [MedicineSearchController::class, 'search']);
    Route::get('medicines/search/ingredient', [MedicineSearchController::class, 'searchByIngredient']);
    Route::get('medicines/{id}',   [MedicineSearchController::class, 'show']);
    Route::get('medicines/search/category', [MedicineSearchController::class, 'searchByCategory']);
});
// ── Auth ──────────────────────────────────────────
Route::post('auth/complete-profile', [AuthController::class, 'completeProfile']);

// ── Google ────────────────────────────────────────
Route::get('auth/google',            [GoogleAuthController::class, 'redirect']);
Route::get('auth/google/callback',   [GoogleAuthController::class, 'callback']);



Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');
