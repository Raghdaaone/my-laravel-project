<?php

namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use App\Models\Patient;
use App\Models\User;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    // ─── إكمال البيانات الصحية + إنشاء التوكن ──────────────────────
    // تُستدعى بعد التحقق من Google
    public function completeProfile(Request $request)
    {
        $request->validate([
            'email'     => 'required|email|exists:users,email',
            'gender'    => 'required|in:male,female',
            'weight'    => 'required|numeric|min:1|max:500',
            'age'       => 'required|date',
            'latitude'  => 'nullable|numeric|between:-90,90',
            'longitude' => 'nullable|numeric|between:-180,180',
        ]);
 
        $user = User::query()->where('email', $request->email)
                ->where('role', 'patient')
                ->first();
 
        if (! $user) {
            return response()->json([
                'message' => 'المستخدم غير موجود',
            ], 404);
        }
 
        // تحقق أن Google وثّق الإيميل أولاً
        if (! $user->google_verified) {
            return response()->json([
                'message' => 'يجب التحقق عبر Google أولاً',
            ], 403);
        }
 
        // تحقق أن الملف الطبي ما أنشئ مسبقاً
        if (Patient::where('user_id', $user->id)->exists()) {
            return response()->json([
                'message' => 'البيانات الطبية موجودة مسبقاً',
            ], 422);
        }
 
        Patient::create([
            'user_id'   => $user->id,
            'gender'    => $request->gender,
            'weight'    => $request->weight,
            'age'       => $request->age,
            'latitude'  => $request->latitude  ?? null,
            'longitude' => $request->longitude ?? null,
        ]);
 
        $token = $user->createToken(
            'patient-token',
            ['*'],
            now()->addDays(7)
        )->plainTextToken;
 
        return response()->json([
            'message' => 'تم إكمال التسجيل بنجاح',
            'token'   => $token,
            'user'    => [
                'id'    => $user->id,
                'name'  => $user->name,
                'email' => $user->email,
                'role'  => $user->role, 'medical_info' => [
            'gender'    => $request->gender,
            'weight'    => $request->weight,
            'age'       => $request->age,
            'latitude'  => $request->latitude  ?? null,
            'longitude' => $request->longitude ?? null,
        ],
            ],
        ], 201);
    }
}
