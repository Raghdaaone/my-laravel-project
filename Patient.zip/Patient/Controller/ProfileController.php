<?php

namespace App\Http\Controllers\Patient;
use App\Models\Patient;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
class ProfileController extends Controller
{
    // ─── عرض الملف الشخصي ─────────────────────────────────────────────
    public function show(Request $request)
    {
        $user    = $request->user();
        $patient = Patient::where('user_id', $user->id)->first();

        return response()->json([
            'message' => 'تم جلب الملف الشخصي بنجاح',
            'data'    => [
                // بيانات الحساب
                'id'         => $user->id,
                'name'  => $user->name,
                'email'      => $user->email,
                'phone'      => $user->phone,
                // البيانات الطبية
                'medical_info' => [
                    'gender'    => $patient?->gender,
                    'weight'    => $patient?->weight,
                    'age'       => $patient?->age,
                    'latitude'  => $patient?->latitude,
                    'longitude' => $patient?->longitude,
                ],
            ],
        ], 200);
    }

    // ─── تعديل الملف الشخصي ───────────────────────────────────────────
    public function update(Request $request)
    {
        $user = $request->user();

        $request->validate([
            // بيانات الحساب — اختيارية
            'name'  => 'sometimes|string|max:100',
            'phone'      => 'sometimes|string|max:150',
            // البيانات الطبية — اختيارية
            'gender'     => 'sometimes|in:male,female',
            'weight'     => 'sometimes|numeric|min:1|max:500',
            'age'        => 'sometimes|integer|min:1|max:120',
            'latitude'   => 'sometimes|nullable|numeric',
            'longitude'  => 'sometimes|nullable|numeric',
        ]);

        // عدّل بيانات الحساب لو أُرسلت
        $user->fill($request->only([
         'name', 'phone',
        ]))->save();

        // عدّل البيانات الطبية لو أُرسلت
        $patient = Patient::where('user_id', $user->id)->first();

        if ($patient) {
            $patient->update($request->only([
                'gender', 'weight', 'age', 'latitude', 'longitude',
            ]));
        }

        // أرجع البيانات المحدثة كاملة
        return response()->json([
            'message' => 'تم تعديل الملف الشخصي بنجاح',
            'data'    => [
                'id'         => $user->id,
                'name'  => $user->name,
                'email'      => $user->email,
                'phone'      => $user->phone,
                'medical_info' => [
                    'gender'    => $patient?->gender,
                    'weight'    => $patient?->weight,
                    'age'       => $patient?->age,
                    'latitude'  => $patient?->latitude,
                    'longitude' => $patient?->longitude,
                ],
            ],
        ], 200);
    }

    // ─── تغيير كلمة المرور ────────────────────────────────────────────
    public function changePassword(Request $request)
    {
        $user = $request->user();

        $request->validate([
            'current_password'          => 'required|string',
            'new_password'              => 'required|string|min:8|confirmed',
            'new_password_confirmation' => 'required|string',
        ]);

        // تحقق من كلمة المرور الحالية
        if (! Hash::check($request->current_password, $user->password)) {
            return response()->json([
                'message' => 'كلمة المرور الحالية غير صحيحة',
            ], 422);
        }

        // تحقق أن كلمة المرور الجديدة مختلفة عن القديمة
        if (Hash::check($request->new_password, $user->password)) {
            return response()->json([
                'message' => 'كلمة المرور الجديدة يجب أن تكون مختلفة عن القديمة',
            ], 422);
        }

        // حدّث كلمة المرور
        $user->fill([
            'password' => Hash::make($request->new_password),
        ])->save();

        // احذف كل التوكنات — يجبره على تسجيل دخول من جديد
        $user->tokens()->delete();

        return response()->json([
            'message' => 'تم تغيير كلمة المرور بنجاح. سجّل دخولك من جديد',
        ], 200);
    }
}

