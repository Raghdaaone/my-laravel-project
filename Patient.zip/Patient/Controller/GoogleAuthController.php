<?php

namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use App\Models\Patient;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Laravel\Socialite\Facades\Socialite;
class GoogleAuthController extends Controller
{
    // ─── ① المستخدم يضغط "تسجيل دخول بـ Google" ─────────────────────
    public function redirect()
    {
        return Socialite::driver('google')->redirect();
    }

    // ─── ② Google يرجع بعد التحقق (للتسجيل) ─────────────────────────
    public function callback()
    {
        try {
            $googleUser = Socialite::driver('google')->user();
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'فشل التحقق من Google',
            ], 401);
        }

        $user = User::where('email', '=', $googleUser->getEmail(), 'and')->first();

        if (! $user) {
            return response()->json([
                'message' => 'الإيميل غير مسجل. سجّل حسابك أولاً',
            ], 404);
        }

        $user->update([
            'google_id'       => $googleUser->getId(),
            'google_verified' => true,
        ]);

        return response()->json([
            'message'       => 'تم التحقق من Google بنجاح. أكمل بياناتك الطبية',
            'email'         => $user->email,
            'needs_profile' => ! Patient::where('user_id', '=', $user->id, 'and')->exists(),
        ], 200);
    }


     
}
