<?php

namespace App\Http\Controllers\Patient;
use App\Models\Medicine;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MedicineSearchController extends Controller
{
    public function search(Request $request)
    {
        $request->validate([
            'q' => 'required|string|min:1|max:200',
        ]);
        $search = $request->input('q');

        $medicines = Medicine::with('activeIngredient')
            ->where(function ($query) use ($search) {
                $query->where('name', 'LIKE', "%{$search}%")
                      ->orWhereHas('activeIngredient', function ($q) use ($search) {
                          $q->where('name', 'LIKE', "%{$search}%");
                      });
            })
            ->select('id', 'name', 'category', 'dosage_form', 'strength', 'indication', 'ingredient_id')
            ->get(); // ← كل النتائج في صفحة واحدة — الـ Scroll Bar في Vue

        // لو ما في نتائج
        if ($medicines->isEmpty()) {
            return response()->json([
                'message' => 'لا توجد أدوية تطابق بحثك',
                'data'    => [],
            ], 200);
        }

        return response()->json([
            'message' => 'تم البحث بنجاح',
            'total'   => $medicines->count(), // ← عدد النتائج
           'data'    => $medicines->map(function ($medicine) {
                return [
                    'id'                => $medicine->id,
                    'name'              => $medicine->name,
                    'category'          => $medicine->category,
                    'dosage_form'       => $medicine->dosage_form,
                    'strength'          => $medicine->strength,
                    'active_ingredient' => $medicine->activeIngredient?->name,
                    'indication'        => $medicine->indication,
                ];
            }),
        ], 200);
    }   // ─── 2. البحث بالمادة الفعالة ─────────────────────────────────────
    public function searchByIngredient(Request $request)
    {
        $request->validate([
            'q' => 'required|string|min:1|max:200',
        ]);

        $search = $request->input('q');

        $medicines = Medicine::with('activeIngredient')
            ->whereHas('activeIngredient', function ($query) use ($search) {
                $query->where('name', 'LIKE', "%{$search}%");
            })
            ->select('id', 'name', 'category', 'dosage_form', 'strength', 'indication', 'ingredient_id')
            ->get();

        if ($medicines->isEmpty()) {
            return response()->json([
                'message' => 'لا توجد أدوية تطابق هذه المادة الفعالة',
                'data'    => [],
            ], 200);
        }

        return response()->json([
            'message' => 'تم البحث بنجاح',
            'total'   => $medicines->count(),
            'data'    => $medicines->map(function ($medicine) {
                return [
                    'id'                => $medicine->id,
                    'name'              => $medicine->name,
                    'category'          => $medicine->category,
                    'dosage_form'       => $medicine->dosage_form,
                    'strength'          => $medicine->strength,
                    'indication'        => $medicine->indication,
                    'active_ingredient' => $medicine->activeIngredient?->name,
                ];
            }),
        ], 200);
    }
    // ─── البحث بالتصنيف ───────────────────────────────────────────────
public function searchByCategory(Request $request)
{
    $request->validate([
        'category' => 'required|string|max:150',
    ]);

    $medicines = Medicine::with('activeIngredient')
        ->where('category', $request->category)
        ->select('id', 'name', 'category', 'dosage_form', 'strength', 'indication', 'ingredient_id')
        ->get();

    if ($medicines->isEmpty()) {
        return response()->json([
            'message' => 'لا توجد أدوية في هذا التصنيف',
            'data'    => [],
        ], 200);
    }

    return response()->json([
        'message' => 'تم البحث بنجاح',
        'total'   => $medicines->count(),
        'data'    => $medicines->map(function ($medicine) {
            return [
                'id'                => $medicine->id,
                'name'              => $medicine->name,
                'category'          => $medicine->category,
                'dosage_form'       => $medicine->dosage_form,
                'strength'          => $medicine->strength,
                'indication'        => $medicine->indication,
                'active_ingredient' => $medicine->activeIngredient?->name,
            ];
        }),
    ], 200);
}

    // ─── عرض تفاصيل دواء واحد ─────────────────────────────────────────
    public function show(int $id)
    {
        $medicine = Medicine::with('activeIngredient')->find($id);

        if (! $medicine) {
            return response()->json([
                'message' => 'الدواء غير موجود',
            ], 404);
        }

        return response()->json([
            'message' => 'تم جلب تفاصيل الدواء بنجاح',
            'data'    => [
                'id'                => $medicine->id,
                'name'              => $medicine->name,
                'category'          => $medicine->category,
                'dosage_form'       => $medicine->dosage_form,
                'strength'          => $medicine->strength,
                'indication'        => $medicine->indication,
                'active_ingredient' => [
                    'id'             => $medicine->activeIngredient?->id,
                    'name'           => $medicine->activeIngredient?->name,
                    'classification' => $medicine->activeIngredient?->classification,
                ],
            ],
        ], 200);
    }
}

