@extends('layouts.patient') @section('content')
<div class="p-6 max-w-4xl mx-auto">
    <div class="flex items-center justify-between mb-6">
        <div class="flex items-center gap-3">
            <div class="p-3 bg-blue-50 text-brandSky rounded-2xl text-xl">⏰</div>
            <div>
                <h2 class="text-xl font-bold text-gray-800">المنبهات الطبية</h2>
                <p class="text-xs text-gray-500">تابع مواعيد جرعات أدويتك المضافة وقم بإدارتها</p>
            </div>
        </div>
    </div>

    <div class="space-y-4">
        @forelse($reminders as $reminder)
            <div class="flex items-center justify-between p-4 bg-white border border-gray-100 rounded-2xl shadow-sm transition hover:shadow-md">
                
                <div class="flex flex-col gap-1.5">
                    <div class="flex items-center gap-2 flex-wrap">
                        <span class="px-2.5 py-1 bg-green-50 text-green-600 rounded-xl text-xs font-bold flex items-center gap-1">
                            💊 {{ $reminder->patientHistory->medicine->name ?? 'دواء غير معروف' }}
                        </span>
                        <span class="px-2.5 py-1 bg-blue-50 text-blue-600 rounded-xl text-xs">
                            المرض: {{ $reminder->patientHistory->disease->Name ?? 'غير محدد' }}
                        </span>
                    </div>
                    
                    <div class="text-xs text-gray-500 flex items-center gap-4 mt-0.5">
                        <span class="flex items-center gap-1">⏱️ الموعد: <strong class="text-gray-700">{{ $reminder->reminder_time }}</strong></span>
                        <span class="flex items-center gap-1">🔄 التكرار: <strong class="text-gray-700">{{ $reminder->frequency }}</strong></span>
                    </div>
                </div>

                <div class="flex items-center gap-2">
                    <button onclick="openEditModal('{{ $reminder->id }}', '{{ $reminder->reminder_time }}', '{{ $reminder->frequency }}')" 
                            class="px-3 py-1.5 bg-gray-50 hover:bg-blue-50 text-gray-600 hover:text-blue-600 rounded-xl transition text-xs font-semibold flex items-center gap-1">
                        ✏️ تعديل
                    </button>

                    <form action="{{ route('patient.reminders.destroy', $reminder->id) }}" method="POST" onsubmit="return confirm('هل أنتِ متأكدة من حذف هذا التنبيه؟')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="px-3 py-1.5 bg-gray-50 hover:bg-red-50 text-gray-500 hover:text-red-500 rounded-xl transition text-xs font-semibold flex items-center gap-1">
                            🗑️ حذف
                        </button>
                    </form>
                </div>
            </div>
        @empty
            <div class="text-center py-12 bg-white rounded-2xl border border-gray-100 text-gray-400 text-xs">
                📋 لا توجد منبهات مضافة حالياً لجرعاتك الطبية.
            </div>
        @endforelse
    </div>
</div>

<div id="editReminderModal" class="fixed inset-0 bg-black/40 backdrop-blur-sm hidden flex items-center justify-center z-50 transition-all">
    <div class="bg-white rounded-3xl p-6 w-full max-w-md shadow-xl border border-gray-100 mx-4">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-sm font-bold text-gray-800 flex items-center gap-1.5">✏️ تعديل منبه الجرعة</h3>
            <button onclick="closeEditModal()" class="text-gray-400 hover:text-gray-600 text-lg">&times;</button>
        </div>

        <form id="editReminderForm" method="POST">
            @csrf
            @method('PUT')

            <div class="space-y-4">
                <div>
                    <label class="block text-xs font-bold text-gray-700 mb-2">وقت التذكير الجديد:</label>
                    <input type="time" id="modal_reminder_time" name="reminder_time" required
                           class="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs focus:outline-none focus:border-brandSky focus:bg-white transition">
                </div>

                <div>
                    <label class="block text-xs font-bold text-gray-700 mb-2">معدل التكرار:</label>
                    <select id="modal_frequency" name="frequency" required
                            class="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs focus:outline-none focus:border-brandSky focus:bg-white transition">
                        <option value="Daily">يومياً (Daily)</option>
                        <option value="Weekly">أسبوعياً (Weekly)</option>
                        <option value="Monthly">شهرياً (Monthly)</option>
                    </select>
                </div>
            </div>

            <div class="flex items-center gap-2 mt-6">
                <button type="submit" class="flex-1 py-2.5 bg-brandSky text-white rounded-xl text-xs font-bold hover:bg-opacity-90 shadow-sm transition">
                    حفظ التحديثات
                </button>
                <button type="button" onclick="closeEditModal()" class="px-4 py-2.5 bg-gray-100 text-gray-500 rounded-xl text-xs font-bold hover:bg-gray-200 transition">
                    إلغاء
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function openEditModal(id, currentTime, currentFrequency) {
    const modal = document.getElementById('editReminderModal');
    const form = document.getElementById('editReminderForm');
    
    // 1. تعيين القيم الحالية في حقول الإدخال ليسهل على المريض تعديلها
    document.getElementById('modal_reminder_time').value = currentTime;
    document.getElementById('modal_frequency').value = currentFrequency;
    
    // 2. تحديث رابط الـ Action بشكل ديناميكي ليتوجه للتنبيه المختار بدقة
    form.action = `/patient/reminders/${id}`;
    
    // 3. عرض النافذة
    modal.classList.remove('hidden');
}

function closeEditModal() {
    const modal = document.getElementById('editReminderModal');
    modal.classList.add('hidden');
}
</script>
@endsection