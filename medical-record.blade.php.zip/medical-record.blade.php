@extends('layouts.patient')

@section('content')
<div class="max-w-6xl mx-auto space-y-6" dir="rtl">

    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
        <div class="text-right">
            <h1 class="text-xl font-bold text-gray-800 flex items-center gap-2">
              <img src="{{ asset('images/image copy.png') }}" 
         alt="شعار دوانا" 
         class="w-16 h-16 rounded-full mx-auto object-cover shadow-md border-2 border-brandSky/30 p-0.5">

                <span>سجلي الطبي</span>
            </h1>
            <p class="text-xs text-gray-400 mt-1">تابع حالاتك الصحية، الأدوية الموصوفة والمواعيد بدقة</p>
        </div>
        
        <button onclick="openModal('addEntryModal')" class="inline-flex items-center justify-center gap-2 px-5 py-3 bg-brandBlue text-white font-bold text-xs rounded-xl hover:bg-blue-800 transition shadow-lg shadow-blue-200/50 text-right">
            <i class="fas fa-plus"></i>
            <span>إضافة حالة جديدة</span>
        </button>
    </div>

    @if(session('success'))
        <div class="p-4 bg-emerald-50 border border-emerald-100 rounded-xl text-emerald-700 text-xs font-semibold flex items-center justify-between">
            <span class="flex items-center gap-2">
                <i class="fas fa-check-circle"></i> {{ session('success') }}
            </span>
        </div>
    @endif

    @if($errors->any())
        <div class="p-4 bg-red-50 border border-red-100 rounded-xl text-red-600 text-xs">
            <ul class="list-disc list-inside space-y-1">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="space-y-4">
        @forelse($history as $entry)
            @php
                // ✨ تم تعديل التسمية هنا إلى الحرف الكبير Name لمطابقة قاعدة البيانات والموديل لديكِ
                $diseaseName = ($entry->disease && trim($entry->disease->Name) !== '') ? $entry->disease->Name : 'مرض غير محدد';
                $medicineName = ($entry->medicine && trim($entry->medicine->name) !== '') ? $entry->medicine->name : 'دواء غير محدد';
                $medicineId = $entry->medicine_id ?? '';
                $diseaseId = $entry->disease && $entry->disease->Id ? $entry->disease->Id : ($entry->disease_id ?? '');
            @endphp

            <div class="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 transition-all duration-200 hover:bg-slate-50/80 hover:shadow-md hover:border-blue-100">
    
                <div class="flex flex-col sm:items-start justify-center gap-2 text-right">
                    <div class="flex flex-wrap items-center gap-2">
                        <span class="inline-flex items-center gap-1 px-4 py-1 bg-blue-50 text-brandBlue rounded-full text-[14px] font-bold border border-blue-100">
                            <span class="text-blue-400 font-medium ml-0.5">المرض:</span>
                            {{ $diseaseName }}
                        </span>

                        <span class="inline-flex items-center gap-1 px-4 py-1 bg-emerald-50 text-emerald-600 rounded-full text-[14px] font-bold border border-emerald-100">
                            <span class="text-emerald-400 font-medium ml-0.5">الدواء:</span>
                            {{ $medicineName }}
                        </span>
                    </div>
                    
                    <p class="text-[11px] text-gray-400 font-medium px-1">
                        تاريخ الإضافة: {{ $entry->created_at ? $entry->created_at->format('Y-m-d') : 'غير محدد' }}
                    </p>
                </div>

                <div class="flex items-center gap-2">
                    <form action="{{ route('patient.medical-record.destroy', $entry->id) }}" method="POST" onsubmit="return confirm('هل أنتِ متأكدة من حذف هذه الحالة بالكامل؟ 🗑️');" class="inline">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="w-9 h-9 rounded-full bg-gray-50 text-gray-400 hover:bg-red-50 hover:text-red-500 flex items-center justify-center text-xs transition" title="حذف بالكامل">
                            <i class="fas fa-trash-alt text-sm"></i>
                        </button>
                    </form>
                    
                    <button onclick="openEditModal('{{ $entry->id }}', '{{ $diseaseName }}', '{{ $medicineId }}', '{{ $diseaseId }}')" class="w-9 h-9 rounded-full bg-gray-50 text-gray-400 hover:bg-amber-50 hover:text-amber-500 flex items-center justify-center text-xs transition" title="تعديل">
                        <i class="fas fa-pen text-xs"></i>
                    </button>

                    <button onclick="openReminderModal('{{ $entry->id }}')" class="w-9 h-9 rounded-full bg-gray-50 text-gray-400 hover:bg-blue-50 hover:text-brandSky flex items-center justify-center text-xs transition" title="ضبط منبه">
                        <i class="fas fa-bell text-sm"></i>
                    </button>
                </div>

            </div>
        @empty
            <div class="col-span-full bg-white rounded-2xl border border-gray-100 py-12 flex flex-col items-center justify-center text-center shadow-sm">
                <img src="{{ asset('admin_assets/img/undraw_posting_photo.svg') }}" class="w-44 h-44 object-contain mb-4 opacity-70">
                <p class="text-sm font-medium text-gray-400">سجلكِ الطبي فارغ حالياً، يمكنكِ إضافة حالات جديدة بالزر بالأعلى.</p>
            </div>
        @endforelse
    </div>

    <div id="addEntryModal" class="fixed inset-0 bg-slate-900/40 backdrop-blur-sm hidden flex items-center justify-center p-4 z-50">
        <div class="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-gray-50 text-right animate-fade-in">
            <div class="flex items-center justify-between border-b border-gray-50 pb-3 mb-4">
                <h5 class="text-base font-bold text-gray-800">إضافة حالة طبية جديدة</h5>
                <button onclick="closeModal('addEntryModal')" class="text-gray-400 hover:text-gray-600 text-lg">&times;</button>
            </div>
            <form action="{{ route('patient.medical-record.add') }}" method="POST" class="space-y-4">
                @csrf
             <div>
                    <label class="block text-xs font-bold text-gray-700 mb-2">اختر المرض:</label>
                    <select id="diseaseSelect" onchange="fetchMedicines(this.value)" class="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs focus:outline-none focus:border-brandSky focus:bg-white transition" name="disease_id" required>
                    <option value="" disabled selected>-- اختر المرض من القائمة --</option>
                    @foreach($diseases as $disease)
                        <option value="{{ $disease->Id }}">{{ $disease->Name }}</option>
                    @endforeach
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-bold text-gray-700 mb-2">اختر الدواء المصاحب:</label>
                    <select id="medicineSelect" class="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs focus:outline-none focus:border-brandSky focus:bg-white transition" name="medicine_id" required>
                        <option value="" disabled selected>-- يرجى اختيار المرض أولاً --</option>
                    </select>
                </div>
                <div class="flex justify-start gap-2 pt-3 border-t border-gray-50">
                    <button type="submit" class="inline-flex items-center justify-center gap-2 px-5 py-3 bg-brandBlue text-white font-bold text-xs rounded-xl hover:bg-blue-800 transition shadow-lg shadow-blue-200/50 text-right">حفظ السجل</button>
                    <button type="button" onclick="closeModal('addEntryModal')" class="px-4 py-2 bg-gray-100 text-gray-500 font-bold text-xs rounded-xl hover:bg-gray-200 transition">إلغاء</button>
                </div>
            </form>
        </div>
    </div>

    <div id="editEntryModal" class="fixed inset-0 bg-slate-900/40 backdrop-blur-sm hidden flex items-center justify-center p-4 z-50">
        <div class="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-gray-50 text-right animate-fade-in">
            <div class="flex items-center justify-between border-b border-gray-50 pb-3 mb-4">
                <h5 class="text-base font-bold text-gray-800">تعديل الدواء للحالة</h5>
                <button onclick="closeModal('editEntryModal')" class="text-gray-400 hover:text-gray-600 text-lg">&times;</button>
            </div>
            <form id="editEntryForm" method="POST" class="space-y-4">
                @csrf
                @method('PUT')
                <div>
                    <label class="block text-xs font-bold text-gray-700 mb-2">المرض (ثابت):</label>
                    <input type="text" id="editDiseaseName" class="w-full px-3 py-2.5 bg-gray-100 border border-gray-200 rounded-xl text-xs text-gray-500 outline-none font-medium" readonly>
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-700 mb-2">اختر الدواء الجديد:</label>
                    <select class="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs focus:outline-none focus:border-brandSky focus:bg-white transition" id="editMedicineSelect" name="medicine_id" required>
                        @foreach($medicines as $medicine)
                            <option value="{{ $medicine->id }}">{{ $medicine->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="flex justify-start gap-2 pt-3 border-t border-gray-50">
                    <button type="submit" class="px-4 py-2 bg-amber-500 text-white font-bold text-xs rounded-xl hover:bg-amber-600 transition">تحديث الدواء</button>
                    <button type="button" onclick="closeModal('editEntryModal')" class="px-4 py-2 bg-gray-100 text-gray-500 font-bold text-xs rounded-xl hover:bg-gray-200 transition">إلغاء</button>
                </div>
            </form>
        </div>
    </div>

    <div id="reminderModal" class="fixed inset-0 bg-slate-900/40 backdrop-blur-sm hidden flex items-center justify-center p-4 z-50">
        <div class="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-gray-50 text-right animate-fade-in">
            <div class="flex items-center justify-between border-b border-gray-50 pb-3 mb-4">
                <h5 class="text-base font-bold text-gray-800 flex items-center gap-1.5"><i class="fas fa-bell text-amber-500"></i> ضبط منبه تذكير الدواء</h5>
                <button onclick="closeModal('reminderModal')" class="text-gray-400 hover:text-gray-600 text-lg">&times;</button>
            </div>
            <form action="{{ route('patient.reminders.store') }}" method="POST" class="space-y-4">
                @csrf
                <input type="hidden" id="reminderHistoryId" name="history_id">
                <div>
                    <label class="block text-xs font-bold text-gray-700 mb-2">وقت الجرعة (ساعة:دقيقة):</label>
                    <input type="time" name="reminder_time" class="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs focus:outline-none focus:border-brandSky focus:bg-white transition text-right" required value="08:00">
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-700 mb-2">معدل التكرار:</label>
                    <select class="w-full px-3 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs focus:outline-none focus:border-brandSky focus:bg-white transition" name="frequency">
                        <option value="daily">يومياً (Daily)</option>
                        <option value="weekly">أسبوعياً (Weekly)</option>
                    </select>
                </div>
                <div class="flex justify-start gap-2 pt-3 border-t border-gray-50">
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white font-bold text-xs rounded-xl hover:bg-blue-700 transition">تفعيل المنبه ⏰</button>
                    <button type="button" onclick="closeModal('reminderModal')" class="px-4 py-2 bg-gray-100 text-gray-500 font-bold text-xs rounded-xl hover:bg-gray-200 transition">إلغاء</button>
                </div>
            </form>
        </div>
    </div>

</div>
@endsection

@push('scripts')
<script>
    function openModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }
    }

    function closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('flex');
            modal.classList.add('hidden');
        }
    }
    // دالة جلب الأدوية بناءً على المرض المختار
    function fetchMedicines(diseaseId) {
        const medicineSelect = document.getElementById('medicineSelect');
        
        // تغيير النص أثناء التحميل لتبدو احترافية
        medicineSelect.innerHTML = '<option value="" disabled selected>⏳ جاري البحث عن الأدوية المرتبطة...</option>';

        // إرسال طلب للمسار الذي أنشأناه
        fetch(`/patient/medical-record/get-medicines/${diseaseId}`)
            .then(response => response.json())
            .then(data => {
                // تفريغ القائمة
                medicineSelect.innerHTML = '';
                
                if (data.length === 0) {
                    medicineSelect.innerHTML = '<option value="" disabled selected>⚠️ لا توجد أدوية مسجلة في البروتوكول لهذا المرض</option>';
                } else {
                    medicineSelect.innerHTML = '<option value="" disabled selected>-- اختر الدواء المناسب --</option>';
                    // إضافة الأدوية المجلوبة
                    data.forEach(med => {
                        medicineSelect.innerHTML += `<option value="${med.id}">${med.name}</option>`;
                    });
                }
            })
            .catch(error => {
                console.error('Error fetching medicines:', error);
                medicineSelect.innerHTML = '<option value="" disabled selected>❌ حدث خطأ في جلب الأدوية</option>';
            });
    }

    function openEditModal(id, diseaseName, currentMedicineId, currentDiseaseId) {
        document.getElementById('editEntryForm').action = `/patient/medical-record/update/${id}`;
        document.getElementById('editDiseaseName').value = diseaseName;
        document.getElementById('editMedicineSelect').value = currentMedicineId;
        
        let diseaseInput = document.getElementById('editDiseaseIdInput');
        if (!diseaseInput) {
            diseaseInput = document.createElement('input');
            diseaseInput.type = 'hidden';
            diseaseInput.id = 'editDiseaseIdInput';
            diseaseInput.name = 'disease_id';
            document.getElementById('editEntryForm').appendChild(diseaseInput);
        }
        diseaseInput.value = currentDiseaseId;

        openModal('editEntryModal');
    }

    function openReminderModal(historyId) {
        document.getElementById('reminderHistoryId').value = historyId;
        openModal('reminderModal');
    }

    window.onclick = function(event) {
        const modals = ['addEntryModal', 'editEntryModal', 'reminderModal'];
        modals.forEach(modalId => {
            const modal = document.getElementById(modalId);
            if (event.target === modal) {
                closeModal(modalId);
            }
        });
    }
</script>
@endpush