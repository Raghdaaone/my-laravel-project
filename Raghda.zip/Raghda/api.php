<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Patient\ProfileController;
use App\Http\Controllers\Patient\MedicineSearchController;
use App\Http\Controllers\Patient\AuthController;
use App\Http\Controllers\Patient\GoogleAuthController;
use App\Http\Controllers\Admin\AuthController as AdminAuthController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\MedicineController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Patient\MedicalRecordController;
use App\Http\Controllers\Patient\MedicationReminderController;
use App\Http\Controllers\Admin\HealthcareCenterController;
use App\Http\Controllers\Patient\PatientCenterApiController;

Route::post('patient/login',       [AuthController::class,      'login']);

Route::post('auth/complete-profile', [AuthController::class,       'completeProfile']);
Route::get('auth/google',            [GoogleAuthController::class, 'redirect']);
Route::get('auth/google/callback',   [GoogleAuthController::class, 'callback']);

Route::post('admin/login', [AdminAuthController::class, 'login']);

Route::middleware(['auth:sanctum', 'admin'])->prefix('admin')->group(function () {
    Route::post('logout', [AdminAuthController::class, 'logout']);
Route::get('dashboard', [DashboardController::class, 'index']);

Route::prefix('medicines')->group(function () {
        Route::get('index',        [MedicineController::class, 'index']);
        Route::post('store',       [MedicineController::class, 'store']);
        Route::get('{id}',    [MedicineController::class, 'show']);
        Route::put('{id}',    [MedicineController::class, 'update']);
        Route::delete('{id}', [MedicineController::class, 'destroy']);
    });

      Route::prefix('users')->group(function () {

        Route::get('/',                   [UserController::class, 'index']);
        Route::post('store',                  [UserController::class, 'store']);
        Route::get('{id}',               [UserController::class, 'show']);
        Route::put('{id}',               [UserController::class, 'update']);
        Route::patch('{id}/activate',    [UserController::class, 'activate']);
        Route::patch('{id}/deactivate',  [UserController::class, 'deactivate']);
  });
  Route::prefix('centers')->group(function () {
        Route::get('/',            [HealthcareCenterController::class, 'index']);  
        Route::post('store',       [HealthcareCenterController::class, 'store']);   
        Route::get('{id}/edit',    [HealthcareCenterController::class, 'edit']);    
        Route::put('{id}',         [HealthcareCenterController::class, 'update']); 
        Route::delete('{id}',      [HealthcareCenterController::class, 'destroy']); 
    });
});


Route::middleware(['auth:sanctum'])->prefix('patient')->group(function () {

    Route::post('logout', [AuthController::class, 'logout']);
    Route::get('profile',          [ProfileController::class, 'show']);
    Route::put('profile',          [ProfileController::class, 'update']);
    Route::post('change-password', [ProfileController::class, 'changePassword']);

Route::prefix('medicines')->group(function () {
    Route::get('search',            [MedicineSearchController::class, 'search']);
    Route::get('search/ingredient', [MedicineSearchController::class, 'searchByIngredient']);
    Route::get('search/category',   [MedicineSearchController::class, 'searchByCategory']);
    Route::get('{id}',              [MedicineSearchController::class, 'show']);
    
});
Route::prefix('medical-record')->group(function () {
        Route::get('show',          [MedicalRecordController::class, 'showRecord']);
        Route::post('store',        [MedicalRecordController::class, 'addMedicalEntry']);
        Route::put('update/{id}',   [MedicalRecordController::class, 'updateMedicalEntry']);
    });
Route::prefix('reminders')->group(function () {
        Route::get('/',            [MedicationReminderController::class, 'index']);
        Route::post('store',       [MedicationReminderController::class, 'store']);
        Route::put('update/{id}',  [MedicationReminderController::class, 'update']);
        Route::delete('delete/{id}', [MedicationReminderController::class, 'destroy']);
    });
    
Route::get('healthcare-centers', [PatientCenterApiController::class, 'index']);
});

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

