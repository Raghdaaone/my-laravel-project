/*
 Navicat Premium Dump SQL

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 80033 (8.0.33)
 Source Host           : 127.0.0.1:3306
 Source Schema         : project

 Target Server Type    : MySQL
 Target Server Version : 80033 (8.0.33)
 File Encoding         : 65001

 Date: 11/06/2026 10:44:22
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for healthcare_center
-- ----------------------------
DROP TABLE IF EXISTS `healthcare_center`;
CREATE TABLE `healthcare_center` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(10,8) NOT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `working_hours` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('hospital',' clinic') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'hospital',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of healthcare_center
-- ----------------------------
BEGIN;
INSERT INTO `healthcare_center` (`id`, `name`, `phone`, `email`, `latitude`, `longitude`, `address`, `working_hours`, `type`, `created_at`, `updated_at`) VALUES (1, 'مستشفي الرازي', '021-4781711', 'info@alrazi.med.ly', 32.87366700, 13.13668700, 'ليبيا - طرابلس/ حي الاندلس/طريق قرقارش', 'مفتوح دائماً', 'hospital', '2026-06-08 20:22:29', '2026-06-10 11:30:45');
INSERT INTO `healthcare_center` (`id`, `name`, `phone`, `email`, `latitude`, `longitude`, `address`, `working_hours`, `type`, `created_at`, `updated_at`) VALUES (2, 'مستشفي غوط الشعال التخصصي', '091-3926603\r\n091-4013636', 'info@gh.med.ly', 32.85021300, 13.08262700, 'ليبيا - طرابلس/غوط الشعال/حي القادسية', 'مفتوح دائمًا', 'hospital', '2026-06-08 20:22:29', '2026-06-08 20:23:19');
INSERT INTO `healthcare_center` (`id`, `name`, `phone`, `email`, `latitude`, `longitude`, `address`, `working_hours`, `type`, `created_at`, `updated_at`) VALUES (3, 'مستشفى طرابلس المركزي', '0213605001', 'info@trhos.ly', 32.86739200, 13.23064270, 'ليبيا– طرابلس/ طريق شارع الزاوية ', 'مفتوح دائمًا', 'hospital', '2026-06-08 20:22:29', '2026-06-08 20:23:19');
INSERT INTO `healthcare_center` (`id`, `name`, `phone`, `email`, `latitude`, `longitude`, `address`, `working_hours`, `type`, `created_at`, `updated_at`) VALUES (4, 'مستشفى الخليل', '0213612012', 'info@khalil.ly', 32.87927820, 13.19436520, 'ليبيا - طرابلس /شارع الزاوية', 'مفتوح دائمًا', 'hospital', '2026-06-08 20:22:29', '2026-06-08 20:23:19');
INSERT INTO `healthcare_center` (`id`, `name`, `phone`, `email`, `latitude`, `longitude`, `address`, `working_hours`, `type`, `created_at`, `updated_at`) VALUES (5, ' مستشفى الشيماء', '0922723333', 'info@alshaimaa.ly', 32.83586270, 13.05389440, 'ليبيا - طرابلس/ جنزور/ طريق الغيران الزراعي', 'مفتوح دائمًا', 'hospital', '2026-06-08 20:22:29', '2026-06-08 20:23:19');
INSERT INTO `healthcare_center` (`id`, `name`, `phone`, `email`, `latitude`, `longitude`, `address`, `working_hours`, `type`, `created_at`, `updated_at`) VALUES (6, 'مستشفى الدولي', '0912242280', 'info@ihospital.ly', 32.83450150, 13.04951880, 'ليبيا - طرابلس /جنزور', 'مفتوح دائمًا', 'hospital', '2026-06-08 20:22:29', '2026-06-08 20:23:19');
INSERT INTO `healthcare_center` (`id`, `name`, `phone`, `email`, `latitude`, `longitude`, `address`, `working_hours`, `type`, `created_at`, `updated_at`) VALUES (7, 'مركز انسولين', '0915223573', 'info@anso.ly', 32.82191070, 13.08089820, 'ليبيا - طرابلس / جنزور', 'مفتوح دائمًا', 'hospital', '2026-06-08 20:22:29', '2026-06-08 20:23:19');
INSERT INTO `healthcare_center` (`id`, `name`, `phone`, `email`, `latitude`, `longitude`, `address`, `working_hours`, `type`, `created_at`, `updated_at`) VALUES (8, 'مستشفى الجسر الجديد', '0910015010', '', 32.86397310, 13.23934100, 'ليبيا - طرابلس /الحشان/طريق اولاد بن الحاج', 'مفتوح دائمًا', 'hospital', '2026-06-08 20:22:29', '2026-06-08 20:23:19');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
