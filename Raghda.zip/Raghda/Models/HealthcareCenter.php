<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use App\Models\Specialty;
class HealthcareCenter extends Model
{
    protected $table = 'healthcare_center'; 

    protected $fillable = [
        'name', 
        'phone', 
        'email', 
        'latitude', 
        'longitude', 
        'address', 
        'working_hours',
        'type'    
    ];

    public function specialties(): BelongsToMany
    {
        return $this->belongsToMany(
            Specialty::class,          
            'hospital_specialty',      
            'hospital_id',            
            'specialty_id'           
        );
    }
}