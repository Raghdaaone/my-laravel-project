<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PatientHistory extends Model
{
    protected $table = 'patient_history';
    protected $fillable = [
        'patient_id',
        'disease_id',
        'medicine_id'
    ];
    
    public function patient()
    {
        return $this->belongsTo(Patient::class, 'patient_id');
    }

    public function disease()
    {
        return $this->belongsTo(Disease::class, 'disease_id', 'Id');
    }

    public function medicine()
    {
        return $this->belongsTo(Medicine::class, 'medicine_id');
    }
}