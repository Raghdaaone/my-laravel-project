<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Specialty extends Model
{
    protected $table = 'Specialty'; 

    protected $fillable = ['name'];
    public function healthcareCenters(): BelongsToMany
    {
        return $this->belongsToMany(
            HealthcareCenter::class,
            'hospital_specialty',
            'specialty_id',
            'hospital_id'
        );
    }
}