<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Disease extends Model
{
    protected $table = 'diseases';
     protected $primaryKey = 'Id';
    protected $fillable = [
        'Name',
        'Treatments',
    ];

    public function protocols()
    {
        return $this->hasMany(TreatmentProtocol::class, 'disease_id');
    }
}