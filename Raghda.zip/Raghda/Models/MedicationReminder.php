<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MedicationReminder extends Model
{
    protected $table = 'medication_reminders';

 const UPDATED_AT = 'updated_at';
    const CREATED_AT = 'created_at';
    protected $fillable = [
        'history_id',
        'reminder_time',
        'frequency',
        'is_active'
    ];
    public function patientHistory()
    {
        return $this->belongsTo(PatientHistory::class, 'history_id');
    }
}