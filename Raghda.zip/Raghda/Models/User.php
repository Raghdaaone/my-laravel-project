<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
use HasApiTokens, HasFactory, Notifiable;
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        
        'google_id',
        'google_verified',
        'reset_token',           
        'reset_token_expires_at',
        'name'  ,
        'email',
        'password',
        'phone',
        'role',
        'is_active',

    ];

    // هل هو Admin؟
    public function isAdmin(): bool
    {
        return $this->role === 'admin';
    }

    // هل هو Patient؟
    public function isPatient(): bool
    {
        return $this->role === 'patient';
    }

    // هل حسابه مفعل؟
    public function isActive(): bool
    {
        return $this->is_active === true;
    }

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
      
        'password',
        'remember_token',
    ];
    

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'reset_token_expires_at' => 'datetime',
            "google_verified" => 'boolean',
             'is_active' => 'boolean',
             'role' => 'string',
             'avatar' => 'string',
             'google_id' => 'string',
             'name' => 'string',
             'email' => 'string',
             'phone' => 'string',
             
        ];
    }
     public function patient()
    {
        return $this->hasOne(Patient::class);
    }
}
