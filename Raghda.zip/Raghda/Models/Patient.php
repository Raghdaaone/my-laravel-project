<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Patient extends Model
{
    protected $table = 'patients';
    protected $fillable = [
        'user_id',
        'gender',
        'weight',
        'age',
        'latitude',
        'longitude',
    ];

    protected $casts = [
        'weight'    => 'float',
        'age'       => 'integer',
        'latitude'  => 'float',
        'longitude' => 'float',
    ];
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
    public function medicines()
{
    return $this->belongsToMany(
        Medicine::class, 
        'patient_medicine', // اسم الجدول الوسيط الذي أنشأناه تواً
        'patient_id',       // المفتاح الأجنبي للمريض داخل الجدول الوسيط
        'medicine_id'       // المفتاح الأجنبي للدواء داخل الجدول الوسيط
    );
}
public function diseases()
    {
        return $this->belongsToMany(
            Disease::class,         // الموديل المرتبط (تأكدي من وجود موديل باسم Disease)
            'patient_history',      // اسم الجدول الوسيط في قاعدة البيانات
            'patient_id',           // المفتاح الأجنبي للمريض داخل الجدول الوسيط
            'disease_id'            // المفتاح الأجنبي للمرض داخل الجدول الوسيط
        );
    }
}
