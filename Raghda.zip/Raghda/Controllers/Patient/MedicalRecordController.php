<?php

namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use App\Models\PatientHistory; 
use App\Models\MedicationReminder;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;

class MedicalRecordController extends Controller
{
    public function showRecord(): JsonResponse
    {
        $patient = Auth::user()->patient;

        if (!$patient) {
            return response()->json(['message' => 'الملف الطبي غير موجود'], 404);
        }

        $history = PatientHistory::where('patient_id', $patient->id)
            ->with(['disease', 'medicine'])
            ->get();

        return response()->json([
            'status'  => true,
            'message' => 'تم جلب السجل الطبي بنجاح',
            'count'   => $history->count(),
            'data'    => $history
        ], 200);
    }

    public function addMedicalEntry(Request $request): JsonResponse
    {
        $request->validate([
            'disease_id'  => 'required|exists:diseases,id',  
            'medicine_id' => 'required|exists:medicines,id', 
        ]);

        $patient = Auth::user()->patient;

        if (!$patient) {
            return response()->json(['message' => 'الملف الطبي غير موجود'], 404);
        }

        $exists = PatientHistory::where('patient_id', $patient->id)
            ->where('disease_id', $request->disease_id)
            ->where('medicine_id', $request->medicine_id)
            ->exists();

        if ($exists) {
            return response()->json(['message' => 'هذا المرض وهذا الدواء مسجلان مسبقاً في سجلك الطبي'], 422);
        }

        $entry = PatientHistory::create([
            'patient_id'  => $patient->id,
            'disease_id'  => $request->disease_id,
            'medicine_id' => $request->medicine_id,
        ]);

        return response()->json([
            'status'  => true,
            'message' => 'تم إضافة المرض والدواء بنجاح إلى سجلك الطبي ',
            'data'    => $entry 
        ], 201);
    }
    public function updateMedicalEntry(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'disease_id'  => 'nullable|exists:diseases,id',  
            'medicine_id' => 'nullable|exists:medicines,id', 
        ]);

        $patient = Auth::user()->patient;

        $entry = PatientHistory::where('id', $id)->where('patient_id', $patient->id)->first();

        if (!$entry) {
            return response()->json(['message' => 'السجل الطبي غير موجود أو لا تملك صلاحية تعديله'], 404);
        }

        if ($request->filled('medicine_id') && $request->medicine_id != $entry->medicine_id) {
            
            $hasReminders = MedicationReminder::where('history_id', $entry->id)->exists();

            if ($hasReminders) {
                MedicationReminder::where('history_id', $entry->id)->delete();
            }
        }

        $entry->update($request->only(['disease_id', 'medicine_id']));

        return response()->json([
            'status'  => true,
            'message' => 'تم تحديث السجل الطبي بنجاح، وتم إزالة التنبيهات المرتبطة بالدواء السابق إن وجدت ✏️✅',
            'data'    => $entry
        ], 200);
    }

}