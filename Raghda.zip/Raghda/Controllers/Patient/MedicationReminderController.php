<?php

namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use App\Models\MedicationReminder;
use App\Models\PatientHistory;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;

class MedicationReminderController extends Controller
{
    public function index(): JsonResponse
    {
        $patient = Auth::user()->patient;

        if (!$patient) {
            return response()->json(['message' => 'الملف الطبي غير موجود'], 404);
        }

        $reminders = MedicationReminder::whereHas('patientHistory', function($query) use ($patient) {
                $query->where('patient_id', $patient->id);
            })
            ->with(['patientHistory.disease', 'patientHistory.medicine'])
            ->get();

        return response()->json([
            'status'  => true,
            'message' => 'تم جلب التنبيهات بنجاح ⏰',
            'count'   => $reminders->count(),
            'data'    => $reminders
        ], 200);
    }

    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'history_id'    => 'required|exists:patient_history,id', 
            'reminder_time' => 'required|date_format:H:i',          
            'frequency'     => 'required|string',                   
            'is_active'     => 'nullable|boolean'                   
        ]);

        $patient = Auth::user()->patient;

        $ownsHistory = PatientHistory::where('id', $request->history_id)
            ->where('patient_id', $patient->id)
            ->exists();

        if (!$ownsHistory) {
            return response()->json(['message' => 'غير مصرح لك بإنشاء تنبيه لهذا السجل الطبي'], 403);
        }

        $reminder = MedicationReminder::create([
            'history_id'    => $request->history_id,
            'reminder_time' => $request->reminder_time,
            'frequency'     => $request->frequency,
            'is_active'     => $request->is_active ?? true 
        ]);

        return response()->json([
            'status'  => true,
            'message' => 'تم ضبط منبه الجرعة بنجاح ⏰✅',
            'data'    => $reminder
        ], 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $request->validate([
            'reminder_time' => 'nullable|date_format:H:i',
            'frequency'     => 'nullable|string',
            'is_active'     => 'nullable|boolean'
        ]);

        $patient = Auth::user()->patient;

        $reminder = MedicationReminder::where('id', $id)
            ->whereHas('patientHistory', function($query) use ($patient) {
                $query->where('patient_id', $patient->id);
            })->first();

        if (!$reminder) {
            return response()->json(['message' => 'التنبيه غير موجود أو غير مصرح لك بتعديله'], 404);
        }

        $reminder->update($request->only(['reminder_time', 'frequency', 'is_active']));

        return response()->json([
            'status'  => true,
            'message' => 'تم تحديث التنبيه بنجاح ✏️',
            'data'    => $reminder
        ], 200);
    }

    public function destroy(int $id): JsonResponse
    {
        $patient = Auth::user()->patient;

        $reminder = MedicationReminder::where('id', $id)
            ->whereHas('patientHistory', function($query) use ($patient) {
                $query->where('patient_id', $patient->id);
            })->first();

        if (!$reminder) {
            return response()->json(['message' => 'التنبيه غير موجود أو لا تملك صلاحية حذفه'], 404);
        }

        $reminder->delete();

        return response()->json([
            'status'  => true,
            'message' => 'تم حذف تنبيه الموعد بنجاح 🗑️'
        ], 200);
    }
}