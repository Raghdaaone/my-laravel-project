<?php

namespace App\Http\Controllers\Patient;

use App\Http\Controllers\Controller;
use App\Models\HealthcareCenter;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class PatientCenterApiController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $search = $request->input('q'); // نص البحث عن الاسم أو العنوان
        $specialtyId = $request->input('specialty_id'); // فلترة حسب التخصص إذا رغب

        $centers = HealthcareCenter::with('specialties')
            ->when($search, function ($query, $search) {
                return $query->where('name', 'LIKE', "%{$search}%")
                             ->orWhere('address', 'LIKE', "%{$search}%");
            })
            ->when($specialtyId, function ($query, $specialtyId) {
                return $query->whereHas('specialties', function($q) use ($specialtyId) {
                    $q->where('Specialty.id', $specialtyId);
                });
            })
            ->get();

        return response()->json([
            'status'  => true,
            'message' => 'تم جلب المؤسسات الصحية بنجاح',
            'count'   => $centers->count(),
            'data'    => $centers
        ], 200);
    }
}