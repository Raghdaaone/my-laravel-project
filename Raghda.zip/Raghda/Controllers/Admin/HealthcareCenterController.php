<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\HealthcareCenter;
use App\Models\Specialty;
use Illuminate\Http\Request;

class HealthcareCenterController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search');
        
        $centers = HealthcareCenter::with('specialties')
            ->when($search, function ($query, $search) {
                return $query->where('name', 'LIKE', "%{$search}%")
                             ->orWhere('address', 'LIKE', "%{$search}%");
            })
            ->paginate(10);

       // $all_specialties = Specialty::all();
       // return view('admin.centers.index', compact('centers', 'all_specialties'));
       return response()->json([
            'message' => 'تم جلب المراكز بنجاح',
            'data' => $centers
        ], 200);
    }

   public function store(Request $request)
{
    $data = $request->validate([
        'name'          => 'required|string|max:255',
        'phone'         => 'required|string|max:150',
        'email'         => 'nullable|email',
        'latitude'      => 'required|numeric',
        'longitude'     => 'required|numeric',
        'address'       => 'required|string',
        'working_hours' => 'nullable|string|max:100',
        'specialties'   => 'required|array',
        'type'          => 'required|string|in:hospital,clinic,center'
    ]);

    $specialties = $data['specialties'];
    unset($data['specialties']);

    $center = HealthcareCenter::create($data);
    $center->specialties()->sync($specialties);

    return response()->json([
        'message' => 'تم إضافة المؤسسة الصحية بنجاح ✅',
        'center'  => $center->load('specialties')
    ], 201); 
}
    public function create()
    {
        $specialties = Specialty::all();
        return view('admin.centers.create', compact('specialties'));
    }
    public function edit(int $id)
    {
        $center = HealthcareCenter::findOrFail($id);
        $specialties = Specialty::all();
        return view('admin.centers.edit', compact('center', 'specialties'));
    }
    public function update(Request $request, int $id)
{
    $center = HealthcareCenter::findOrFail($id);
    
    $data = $request->validate([
        'name'          => 'required|string|max:255',
        'phone'         => 'required|string|max:150',
        'email'         => 'nullable|email',
        'latitude'      => 'required|numeric',
        'longitude'     => 'required|numeric',
        'address'       => 'required|string',
        'working_hours' => 'nullable|string|max:100',
        'specialties'   => 'required|array',
        'type'          => 'required|string|in:hospital,clinic,center'
    ]);

    // أزيلي specialties قبل update لأنها ليست عمود في الجدول
    $specialties = $data['specialties'];
    unset($data['specialties']);

    $center->update($data);
    $center->specialties()->sync($specialties);

    return response()->json([
        'message' => 'تم تحديث بيانات المؤسسة بنجاح ✏️',
        'center'  => $center->load('specialties')
    ], 200);
}

    public function destroy(int $id)
    {
        $center = HealthcareCenter::findOrFail($id);
        $center->specialties()->detach(); 
        $center->delete();

       //return redirect()->back()->with('success', 'تم حذف المؤسسة بنجاح 🗑️');
       return response()->json([
            'message' => 'تم حذف المؤسسة بنجاح 🗑️'
        ], 200);
    }

}